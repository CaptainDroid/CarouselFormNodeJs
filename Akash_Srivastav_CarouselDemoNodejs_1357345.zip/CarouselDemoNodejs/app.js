const express = require('express');
const app = express();
const http = require('http');
const path = require('path');
const bodyParser = require('body-parser');
const mongoose = require('mongoose')
const formCarousel = require('form-carousel');
const config = require('./config/database');
const Employee = require('./models/employee.js')


app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended:true}));

const port = process.env.PORT || 3000;
app.set('view engine', 'ejs');

mongoose.connect(config.database);
mongoose.connection.on('connected', function() {
    console.log("Connected to database "+config.database);
});

app.get('/', function(req, res, next) {
    res.sendFile(path.join(__dirname,"index.html"));
});

app.get('/addEmployee', function(req, res, next) {
    
    res.sendFile(path.join(__dirname,"employeeReg.html"));
   // res.render("form");
});

app.get('/test', function(req, res, next){
     res.sendFile(path.join(__dirname,"index2.html"));
})

app.post('/addEmployee', function(req, res, next){
    let newEmployee = new Employee({
        name: req.body.name,
        address: req.body.address,
        email: req.body.email,
        phone: req.body.phone,
        empId: req.body.empId,
        lg: req.body.lg
    });
    
    Employee.AddEmployee(newEmployee, function(err, employee){
        if(err) {
           // res.json({ success: false, message: 'Failed to Register Employee.' });
           res.send("Failed to Register Employee.")
        } else {
           // res.json({ success: true, message: 'Successfully registered Employee!'})
           res.sendFile(path.join(__dirname,"success.html"));
        }
    });
});

app.listen(port, function() {
    console.log("Server started on port "+port);
});