const mongoose = require('mongoose');
const config = require('../config/database');

// Employee Schema

const EmployeeSchema = mongoose.Schema({
    name:{
        type: String,
        required: true
    },
    address:{
        type: String,
        required: true
    },
    email:{
        type:String,
        required: true
    },
    phone:{
        type: Number,
        required: true
    },
    empId:{
        type: String,
        required: true
    },
    lg:{
        type: String,
        required: true
    }
});
const Employee = module.exports = mongoose.model('Employee', EmployeeSchema);

module.exports.AddEmployee = function(newEmployee, callback){
    newEmployee.save(callback);
}