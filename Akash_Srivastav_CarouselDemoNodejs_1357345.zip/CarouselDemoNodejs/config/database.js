module.exports = {
      database: 'mongodb://CaptainDroid:asusnexus7@ds157971.mlab.com:57971/the_notebase',
    secret: 'thenotebase'
};