Make sure that node.js is installed on the system.

For the first time, run the command 

	"npm install"
Then to run the application anytime, open a terminal in this directory and run the command
	"node app"
And open the url localhost:3000/ in the browser.